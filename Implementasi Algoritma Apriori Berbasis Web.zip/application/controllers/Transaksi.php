<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Transaksi extends CI_Controller 
{

	public function __construct()
	{

		parent::__construct();
		$this->load->library('excel');
		
		$this->load->model('Transaksi_model');
		
	}

	public function index()
	{
		$data['title'] = 'Transactions';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$query = $this->db->get('transaksi');
		$data['results'] = $query->result();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('transaksi/index', $data);
		$this->load->view('templates/footer');

	}

	public function import()
	{
		if(isset($_FILES["file"]["name"]))
      {
        $path = $_FILES["file"]["tmp_name"];
        $object = PHPExcel_IOFactory::load($path);
        foreach($object->getWorksheetIterator() as $worksheet)
        {
          $highestRow = $worksheet->getHighestRow();
          $highestColumn = $worksheet->getHighestColumn();
          for($row=2; $row<=$highestRow; $row++)
           {   
             $tanggal = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
             $produk = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
             
             $data[] = array(
                      'transaction_date'        =>    date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($tanggal)),
                      'produk'            =>    $produk
                     );
            }
        }

        $this->Transaksi_model->insertimport($data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
				      Import Success
				      </div>');
				     redirect('transaksi');
        } else {
        	 $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
				      Import Failed
				      </div>');
				     redirect('transaksi');
        } 

    	} 
}