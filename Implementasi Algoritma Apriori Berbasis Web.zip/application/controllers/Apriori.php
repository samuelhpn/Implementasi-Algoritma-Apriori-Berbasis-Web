<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Apriori extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('Apriori_model');

	}

	public function index()
	{
		$data['title'] = 'Apriori';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		
		$data['jumlah'] = 0;
		
			    if(isset($_POST['range_tanggal']) && empty($_POST['min_support']) && empty($_POST['min_confidence'])){


			        $tgl = explode(" - ", $_POST['range_tanggal']);
			        $start =  $this->Apriori_model->format_date($tgl[0]);
			        $end = $this->Apriori_model->format_date($tgl[1]);
			        
			        $this->db->where('transaction_date >=', $start);
					$this->db->where('transaction_date <=', $end);
					$query = $this->db->get("transaksi");
					$data['result'] = $query->result();


					$field_value = array(
                            "start_date"=>$start,
                            "end_date"=>$end,
                            "min_support"=>$_POST['min_support'],
                            "min_confidence"=>$_POST['min_confidence']
                        );
		            $this->Apriori_model->insert("process_log", $field_value);
		            
		            $data['id_process'] = $this->db->insert_id();
			        $data['tanggal'] = $_POST['range_tanggal'];
			        $data['min_support'] = $_POST['min_support'];
			        $data['min_confidence'] = $_POST['min_confidence'];
					$data['jumlah'] = 1;

			    } elseif (!empty($_POST['min_support']) && !empty($_POST['min_confidence'])) {
			    	$data['id_process'] = $_POST['id_process'];
			    	$data['tanggal'] = $_POST['range_tanggal'];
			        $data['min_support'] = $_POST['min_support'];
			        $data['min_confidence'] = $_POST['min_confidence'];
			    	$this->Apriori_model->delete();

			    	$tgl = explode(" - ", $_POST['range_tanggal']);
			        $data['start'] = $this->Apriori_model->format_date($tgl[0]);
			        $data['end'] = $this->Apriori_model->format_date($tgl[1]);

			        

		            $field = array(
		                            "start_date"=>$data['start'],
		                            "end_date"=>$data['end'],
		                            "min_support"=>$_POST['min_support'],
		                            "min_confidence"=>$_POST['min_confidence']
		                        );
		            $where = array(
                            "id"=>$data['id_process']
                        );
		            $this->Apriori_model->update($field, $where);

		            
			        $this->db->where('transaction_date >=',$data['start']);
					$this->db->where('transaction_date <=', $data['end']);
					$query = $this->db->get("transaksi")->num_rows();
			       
			        $data['minSupportRelatif'] = ($_POST['min_support']/$query)*100;
			        

			        $data['results'] = $this->Apriori_model;

		            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
						Proses Apriori Success
						</div>');
		            $data['jumlah'] = 2;

			    }

		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('apriori/index', $data);
		if($data['jumlah'] == 2) {
			$this->load->view('apriori/tablemining', $data);
		}
		$this->load->view('templates/footer');

		

	} 
}