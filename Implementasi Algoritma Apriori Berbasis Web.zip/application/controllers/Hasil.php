<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hasil extends CI_Controller 
{

	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('Apriori_model');

	}

	public function index()
	{
		$data['title'] = 'Result Apriori';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->db->order_by("id", "desc");
		$query = $this->db->get('process_log');
		$data['results'] = $query->result();
		$data['date'] = $this->Apriori_model;

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('hasil/index', $data);
		$this->load->view('templates/footer');
	}

	public function view($id){
		$data['title'] = "View Rule";
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		
		$id_process = $id;
		$data['date'] = $this->Apriori_model;
		$sql = "SELECT
            conf.*, log.start_date, log.end_date
            FROM
             confidence conf, process_log log
            WHERE conf.id_process = '$id_process' "
            . " AND conf.id_process = log.id "
            . " AND conf.from_itemset=2 ";
        $data['query'] = $this->db->query($sql)->result_array();
        $data['jumlah'] = $this->db->query($sql)->num_rows();


        $this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('hasil/detail', $data);
		$this->load->view('templates/footer');
	}

	public function delete($id){
		$this->db->where('id', $id);
        $this->db->delete('process_log');
		$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
		successfully deleted
			</div>');
		redirect('Hasil');
	}
}